#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cctype>

using namespace std;

string cleanWord(const string& word) {
    string clean;
    for (char c : word) {
        if (isalpha(c)) {
            clean += tolower(c);
        }
    }
    return clean;
}

int main() {
    string filename;
    cout << "Fayl nomi: ";
    cin >> filename;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    string longestWord, word;
    string line;
    
    while (getline(file, line)) {
        stringstream ss(line);
        while (ss >> word) {
            string cleanWord = cleanWord(word);
            if (cleanWord.length() > longestWord.length()) {
                longestWord = cleanWord;
            }
        }
    }
    
    file.close();
    
    if (!longestWord.empty()) {
        cout << "Eng uzun so'z: " << longestWord << endl;
        cout << "Uzunligi: " << longestWord.length() << " harf" << endl;
    } else {
        cout << "Faylda so'zlar topilmadi!" << endl;
    }
    
    return 0;
}