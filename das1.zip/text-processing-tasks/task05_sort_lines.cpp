#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    string filename;
    cout << "Fayl nomini kiriting: ";
    cin >> filename;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    vector<string> lines;
    string line;
    while (getline(file, line)) {
        if (!line.empty()) {
            lines.push_back(line);
        }
    }
    file.close();
    
    sort(lines.begin(), lines.end());
    
    string outputFile = "output_files/sorted_" + filename;
    ofstream outFile(outputFile);
    for (const auto& l : lines) {
        outFile << l << endl;
    }
    outFile.close();
    
    cout << "Qatorlar tartiblandi va '" << outputFile << "' fayliga saqlandi!" << endl;
    return 0;
}