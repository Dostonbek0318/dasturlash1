#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

int main() {
    string filename;
    cout << "Fayl nomini kiriting: ";
    cin >> filename;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    int wordCount = 0;
    string line, word;
    while (getline(file, line)) {
        stringstream ss(line);
        while (ss >> word) {
            wordCount++;
        }
    }
    
    cout << "Fayldagi so'zlar soni: " << wordCount << endl;
    file.close();
    return 0;
}