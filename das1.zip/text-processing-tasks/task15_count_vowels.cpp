#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cctype>

using namespace std;

int main() {
    string inputFile, outputFile;
    cout << "Kirish fayli: ";
    cin >> inputFile;
    cout << "Chiqish fayli: ";
    cin >> outputFile;
    
    ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        cout << "Kirish faylini ochib bo'lmadi!" << endl;
        return 1;
    }
    
    ofstream outFile("output_files/" + outputFile);
    if (!outFile.is_open()) {
        cout << "Chiqish faylini yaratib bo'lmadi!" << endl;
        return 1;
    }
    
    string line;
    int numbersFound = 0;
    
    while (getline(inFile, line)) {
        string number;
        for (char c : line) {
            if (isdigit(c) || c == '.' || (c == '-' && !number.empty() && number.back() == '-')) {
                number += c;
            } else if (!number.empty()) {
                outFile << number << endl;
                numbersFound++;
                number.clear();
            }
        }
        if (!number.empty()) {
            outFile << number << endl;
            numbersFound++;
        }
    }
    
    inFile.close();
    outFile.close();
    
    cout << numbersFound << " ta raqam 'output_files/" << outputFile << "' fayliga ajratildi!" << endl;
    return 0;
}