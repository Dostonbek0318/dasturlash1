#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string filename, searchText;
    cout << "Fayl nomi: ";
    cin >> filename;
    cout << "Qidirilayotgan matn: ";
    cin.ignore();
    getline(cin, searchText);
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    string line;
    int lineNumber = 0;
    bool found = false;
    
    cout << "Topilgan qatorlar:" << endl;
    cout << "==================" << endl;
    while (getline(file, line)) {
        lineNumber++;
        if (line.find(searchText) != string::npos) {
            cout << lineNumber << ": " << line << endl;
            found = true;
        }
    }
    
    if (!found) {
        cout << "Matn topilmadi!" << endl;
    }
    
    file.close();
    return 0;
}