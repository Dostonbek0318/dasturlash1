#include <iostream>
#include <fstream>
#include <string>

using namespace std;

string decryptText(const string& text, int key) {
    string result = text;
    for (char& c : result) {
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            c = base + (c - base - key + 26) % 26;
        }
    }
    return result;
}

int main() {
    string filename;
    int key;
    cout << "Shifrlangan fayl nomi: ";
    cin >> filename;
    cout << "Shifr kaliti: ";
    cin >> key;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    string content((istreambuf_iterator<char>(file)), 
                   istreambuf_iterator<char>());
    file.close();
    
    string decrypted = decryptText(content, key);
    
    string outputFile = "output_files/decrypted_" + filename;
    ofstream outFile(outputFile);
    outFile << decrypted;
    outFile.close();
    
    cout << "Fayl shifrdan ochildi: " << outputFile << endl;
    return 0;
}