#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main() {
    int fileCount;
    cout << "Birlashtiriladigan fayllar soni: ";
    cin >> fileCount;
    
    vector<string> filenames(fileCount);
    for (int i = 0; i < fileCount; ++i) {
        cout << i+1 << "-fayl nomi: ";
        cin >> filenames[i];
    }
    
    string outputFile = "output_files/merged_files.txt";
    ofstream output(outputFile);
    
    for (const auto& filename : filenames) {
        ifstream input(filename);
        if (!input.is_open()) {
            cout << filename << " faylini ochib bo'lmadi!" << endl;
            continue;
        }
        
        output << "=== " << filename << " ===" << endl;
        string line;
        while (getline(input, line)) {
            output << line << endl;
        }
        output << endl;
        input.close();
    }
    
    output.close();
    cout << "Fayllar '" << outputFile << "' fayliga birlashtirildi!" << endl;
    return 0;
}