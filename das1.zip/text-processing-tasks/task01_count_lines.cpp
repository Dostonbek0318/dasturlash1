#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string filename;
    cout << "Fayl nomini kiriting: ";
    cin >> filename;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    int lineCount = 0;
    string line;
    while (getline(file, line)) {
        lineCount++;
    }
    
    cout << "Fayldagi qatorlar soni: " << lineCount << endl;
    file.close();
    return 0;
}