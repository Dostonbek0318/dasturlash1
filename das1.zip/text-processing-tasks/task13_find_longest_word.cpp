#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

int main() {
    string filename;
    cout << "Fayl nomi: ";
    cin >> filename;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    int letterCount = 0, spaceCount = 0, punctuationCount = 0, digitCount = 0, totalCount = 0;
    char c;
    
    while (file.get(c)) {
        totalCount++;
        if (isalpha(c)) {
            letterCount++;
        } else if (isdigit(c)) {
            digitCount++;
        } else if (isspace(c)) {
            spaceCount++;
        } else if (ispunct(c)) {
            punctuationCount++;
        }
    }
    
    file.close();
    
    cout << "Statistika:" << endl;
    cout << "============" << endl;
    cout << "Umumiy belgilar: " << totalCount << endl;
    cout << "Harflar: " << letterCount << endl;
    cout << "Raqamlar: " << digitCount << endl;
    cout << "Probellar: " << spaceCount << endl;
    cout << "Tinish belgilari: " << punctuationCount << endl;
    cout << "Boshqa belgilar: " << totalCount - letterCount - digitCount - spaceCount - punctuationCount << endl;
    
    return 0;
}
