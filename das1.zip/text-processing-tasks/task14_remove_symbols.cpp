#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    string inputFile, outputFile;
    cout << "Kirish fayli: ";
    cin >> inputFile;
    cout << "Chiqish fayli: ";
    cin >> outputFile;
    
    ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        cout << "Kirish faylini ochib bo'lmadi!" << endl;
        return 1;
    }
    
    string content((istreambuf_iterator<char>(inFile)), 
                   istreambuf_iterator<char>());
    inFile.close();
    
    // Teskari qilish
    reverse(content.begin(), content.end());
    
    ofstream outFile("output_files/" + outputFile);
    outFile << content;
    outFile.close();
    
    cout << "Matn teskari qilindi va 'output_files/" << outputFile << "' fayliga saqlandi!" << endl;
    return 0;
}