#include <iostream>
#include <fstream>
#include <string>

using namespace std;

string encryptText(const string& text, int key) {
    string result = text;
    for (char& c : result) {
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            c = base + (c - base + key) % 26;
        }
    }
    return result;
}

int main() {
    string filename;
    int key;
    cout << "Fayl nomi: ";
    cin >> filename;
    cout << "Shifr kaliti (1-25): ";
    cin >> key;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    string content((istreambuf_iterator<char>(file)), 
                   istreambuf_iterator<char>());
    file.close();
    
    string encrypted = encryptText(content, key);
    
    string outputFile = "output_files/encrypted_" + filename;
    ofstream outFile(outputFile);
    outFile << encrypted;
    outFile.close();
    
    cout << "Fayl shifrlandi: " << outputFile << endl;
    cout << "Shifr kaliti: " << key << " (eslab qoling!)" << endl;
    return 0;
}