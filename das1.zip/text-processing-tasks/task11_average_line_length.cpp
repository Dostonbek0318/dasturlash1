#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

int main() {
    string filename;
    cout << "Fayl nomi: ";
    cin >> filename;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    double sum = 0.0;
    int count = 0;
    string line;
    
    while (getline(file, line)) {
        stringstream ss(line);
        double number;
        while (ss >> number) {
            sum += number;
            count++;
            cout << "Topilgan raqam: " << number << endl;
        }
    }
    
    file.close();
    
    if (count > 0) {
        double average = sum / count;
        cout << fixed << setprecision(2);
        cout << "Raqamlar soni: " << count << endl;
        cout << "Yig'indi: " << sum << endl;
        cout << "O'rtacha qiymat: " << average << endl;
    } else {
        cout << "Faylda raqamlar topilmadi!" << endl;
    }
    
    return 0;
}