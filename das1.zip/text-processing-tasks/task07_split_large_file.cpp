#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

vector<string> readFileLines(const string& filename) {
    vector<string> lines;
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        lines.push_back(line);
    }
    file.close();
    return lines;
}

int main() {
    string filename;
    int partCount;
    cout << "Fayl nomi: ";
    cin >> filename;
    cout << "Qismlar soni: ";
    cin >> partCount;
    
    vector<string> lines = readFileLines(filename);
    int linesPerPart = lines.size() / partCount;
    int remainder = lines.size() % partCount;
    
    int lineIndex = 0;
    for (int i = 0; i < partCount; ++i) {
        string partName = "output_files/part_" + to_string(i+1) + "_" + filename;
        ofstream partFile(partName);
        
        int currentPartLines = linesPerPart + (i < remainder ? 1 : 0);
        for (int j = 0; j < currentPartLines; ++j) {
            if (lineIndex < lines.size()) {
                partFile << lines[lineIndex++] << endl;
            }
        }
        partFile.close();
        cout << "Yaratildi: " << partName << " (" << currentPartLines << " qator)" << endl;
    }
    
    cout << "Fayl " << partCount << " qismga bo'lindi!" << endl;
    return 0;
}