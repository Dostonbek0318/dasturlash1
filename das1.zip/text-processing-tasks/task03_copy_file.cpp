#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string source, destination;
    cout << "Manba fayl nomi: ";
    cin >> source;
    cout << "Nusxa fayl nomi: ";
    cin >> destination;
    
    ifstream srcFile(source);
    ofstream destFile(destination);
    
    if (!srcFile.is_open() || !destFile.is_open()) {
        cout << "Fayllarni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    string line;
    while (getline(srcFile, line)) {
        destFile << line << endl;
    }
    
    cout << "Fayl muvaffaqiyatli nusxalandi!" << endl;
    srcFile.close();
    destFile.close();
    return 0;
}