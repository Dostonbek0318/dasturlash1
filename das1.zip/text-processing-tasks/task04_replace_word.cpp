#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

int main() {
    string filename, searchWord, replaceWord;
    cout << "Fayl nomi: ";
    cin >> filename;
    cout << "Qidirilayotgan so'z: ";
    cin >> searchWord;
    cout << "Almashtiriladigan so'z: ";
    cin >> replaceWord;
    
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Faylni ochib bo'lmadi!" << endl;
        return 1;
    }
    
    stringstream buffer;
    string line;
    while (getline(file, line)) {
        size_t pos = 0;
        while ((pos = line.find(searchWord, pos)) != string::npos) {
            line.replace(pos, searchWord.length(), replaceWord);
            pos += replaceWord.length();
        }
        buffer << line << endl;
    }
    file.close();
    
    ofstream outFile(filename);
    outFile << buffer.str();
    outFile.close();
    
    cout << "So'z muvaffaqiyatli almashtirildi!" << endl;
    return 0;
}